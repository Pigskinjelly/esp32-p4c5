# ESP32-P4C5 网络监控设备（ipcam）

SC2336 摄像头 → ISP → H.264 硬编 → RTSP 推流，同时 480×480 屏本地预览。

## 硬件

| 部件 | 型号 | 接口 |
|---|---|---|
| 开发板 | OSPTEK ESP32-P4C5-Module **V1.5** | — |
| 屏幕 | OSPTEK **YDP395BT008-V1** 3.95″ 480×480 | MIPI-DSI 2-lane，ST7102 |
| 摄像头 | **SC2336** 2MP | MIPI-CSI 2-lane，24MHz 板载晶振 |
| 音频 | ES8311 + NS4150B + 板载硅麦 | I2S0 |

## 引脚（V1.5 底板）

| 功能 | GPIO |
|---|---|
| 共享 I2C（相机/触摸/ES8311） | SDA=7，SCL=8 |
| LCD 复位 / TE / 背光 | 5 / 4 / 20 |
| 触摸 复位 / 中断 | 6 / 21 |
| 相机复位 CSI_RST（1.8V 域，开漏） | 26 |
| I2S：MCLK/BCLK/WS/DOUT/DIN | 13 / 12 / 10 / 9 / 11 |
| 功放使能（高有效） | 53 |
| 调试串口 UART0 | TX=37，RX=38 |
| SDIO→C5（由 esp_hosted 占用，勿动） | 14–19 |
| C5 复位 | 54 |

## 链路

```
SC2336 800x800 RAW10
   └─ ISP → YUV420
        ├─ PPA（缩放 + YUV→RGB565）→ ST7102 480x480 屏
        └─ /dev/video11 H.264（USERPTR 零拷贝）→ RTP → RTSP :554/stream
```

## 目录

```
main/
├── main.c            启动编排 + 帧回调（预览 + 编码）
├── app_lcd.c/h       ST7102 480x480 驱动（含复位时序坑处理）
├── app_video.c/h     SC2336 采集（esp_video）
├── app_audio.c/h     ES8311 音频
├── app_encoder.c/h   H.264 M2M 编码（新增）
└── rtsp_server.c/h   RTSP/RTP 服务器（新增）
components/esp_lcd_st7102/   厂商屏驱动
```

## 编译

```powershell
$env:IDF_PYTHON_ENV_PATH = "D:\Espressif\python_env\idf5.5_py3.11_env"
. "D:\Espressif\frameworks\esp-idf-v5.5.5\export.ps1"
cd C:\Users\lihaitao\Desktop\ESP32-P4C5\esp32-p4c5-ipcam
idf.py set-target esp32p4
idf.py build
```

> 本机因文档加密驱动（TFsdframe）会破坏编译产物，需先退出加密客户端或把项目目录加入白名单，
> 否则会报 `junk at end of line, first unrecognized character is '%'`。

## 烧录

1. 拨动开关拨到 **P4**；
2. USB 接调试口 Type-C（CH343P，本机为 COM19）；
3. `idf.py -p COM19 flash monitor`。

## 验证

| 阶段 | 预期现象 |
|---|---|
| 上电 | 串口打印 `LCD ready: 480x480`，屏幕亮并显示相机画面 |
| 采集 | 每 50 帧打印 `fps: ~30`，`camera format: 800x800` |
| 编码 | `enc: N frames, last XXXXX B`，I 帧约 20–60KB |
| 推流 | VLC 打开 `rtsp://<设备IP>:554/stream`，5 秒内出画 |

VLC 建议：`vlc rtsp://192.168.x.x:554/stream --rtsp-tcp`（先试默认 UDP，不通再用 TCP）。

## 已知限制

- RTSP 目前只服务单客户端；多客户端需扩展会话管理。
- 未接入 Wi-Fi：需先给 C5 烧 `firmware/ESP32-C5_ESP-Hosted_v2.12.9_merged_0x0.bin`（0x0），
  P4 端再加 `esp_hosted` + `esp_wifi_remote`（2.12.x）。
- 运动检测、mDNS、Web 面板尚未实现（P1/P2）。
- SPS/PPS 依赖首帧编码；若 DESCRIBE 早于首帧，SDP 会自动省略 `sprop-parameter-sets`，
  由码流内参数集兜底。
